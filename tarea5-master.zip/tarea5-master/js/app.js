
(function () {
//esto es una funcion anonima
//y autoejecutable.
  console.log('Hola mundo'); //impresion en consola



}());
var miarray = []; // esto es una varible tipo array
var letra = 'MiString'; //una variable tipo string
var minumero = 3; //variable numerica
miarray.push('Primer elemento'); //elemento de array
miarray.push('Segundo elemento'); //elemento de array
console.log(miarray); //impresion en consola de array
var miObjeto = {}; // variable tipo object
miObjeto.descripcion = 'zapatillas'; //atributos
miObjeto.cantidad = 12; //atributos
console.log(miObjeto);
